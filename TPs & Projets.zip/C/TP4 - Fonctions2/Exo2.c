#include <stdio.h>

void SommeFrac(int a, int b, int c, int d, int *e, int *f) {
    *e = a * d + b * c;
    *f = b * d;
}

void InverseFrac(int *a, int *b){
    int temp = *a;
    *a = *b;
    *b = temp;
}

void main() {
    int a=1, b=1, c=2, d=4, e, f;
    SommeFrac(a, b, c, d, &e, &f);
    printf("%d/%d + %d/%d = %d/%d\n", a, b, c, d, e, f);

    printf("Fraction normal : %d/%d\n", c, d);
    InverseFrac(&c, &d);
    printf("Fraction inversée : %d/%d\n", c, d);
}