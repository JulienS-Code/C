#include <stdio.h>
#include <string.h>

int TransformeMinMaj(char *c) {
    if ((*c >= 'a' && *c <= 'z') || (*c >= 'A' && *c <= 'Z'))
    {
        if (*c >= 'a' && *c <= 'z') {
            *c = *c - 32;
        }     
        return 1;
    }
    return 0;    
}

void main() {
    char c='j';
    printf("1 si c'est une lettre : %d\n", TransformeMinMaj(&c));
    printf("%c\n", c);

    char ch;

    printf("Entrez une suite de caractères : ");
    while ((ch = getchar()) != '\n')
    {
        if (TransformeMinMaj(&ch))
        {
            printf("%c", ch);
        }
    }
    printf("\n");
}