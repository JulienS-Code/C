#include <stdio.h>

void Echange(int a, int b) {
    int temp = a;
    a = b;
    b = temp;
}

void Echange2(int *a, int *b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}

int Echange3(int a, int *b) {
    int temp = a;
    a = *b;
    *b = temp;
    return a;
}

void main() {
    int x=3, y=4;
    Echange(x, y);
    printf("%d %d\n", x, y); // ne marche pas s'il n'y a pas de return dans la fonction

    int a=3, b=4;
    Echange2(&a, &b);
    printf("%d %d\n", a, b); // change l'adresse donc retrouvable depuis le programme principal
    
    int m=3, n=4;
    m = Echange3(m, &n); // affecter la valeur de la variable modifiée dans la fonction pour ne pas la perdre
    printf("%d %d\n", m, n);
}