#include <stdio.h>

#define N 5

void Lecture(int tableau[N]) {
    printf("Entrez %d entiers : \n", N);
    for (int i = 0; i < N; i++) {
        printf("Elément %d : ", i+1);
        scanf("%d", &tableau[i]);
    }
    
}

void Ecriture(int tableau[N]) {
    printf("Contenu du tableau : \n");
    for (int i = 0; i < N; i++) {
        printf("%d", tableau[i]);
    }
    printf("\n");    
}

int Position(int T[N], int x) {
    for (int i = 0; i < N; i++) {
        if (T[i] == x) {
            printf("L'élément %d se trouve en position %d\n", x, i);
            return i;
        }
    }
    printf("Elément %d introuvable dans le tableau\n", x);
    return -1;
}

void main() {
    int tableau[N], x;

    Lecture(tableau);

    Ecriture(tableau);

    printf("Entrez un entier : ");
    scanf("%d", &x);
    Position(tableau, x);
}