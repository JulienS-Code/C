#include <stdio.h>

#define N 10

void EstPremier(int T[], int taille) {
    for (int i = 0; i < 1000; i++) {
        for (int j = 0; j < taille; j++) {
            if (i % 0) {
                /* code */
            }
            
                T[j] = i;
        }        
    }    
}

void RemplirNombresPremiers(int N, int nombres_premiers[]) {
    int nombre = 2; // Commencer par le premier nombre premier
    int i = 0; // Indice dans le tableau des nombres premiers

    while (i < N) {
        bool est_premier = true;

        // Vérifier si nombre est premier
        for (int j = 2; j * j <= nombre; j++) {
            if (nombre % j == 0) {
                est_premier = false;
                break;
            }
        }

        // Si nombre est premier, l'ajouter au tableau
        if (est_premier) {
            nombres_premiers[i] = nombre;
            i++;
        }

        nombre++;
    }
}


void main() {

}