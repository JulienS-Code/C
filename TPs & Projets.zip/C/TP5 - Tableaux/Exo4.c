#include <stdio.h>

#define N 10

int Frequence(int T[], int taille, int x) {
    int frequence = 0;
    for (int i = 0; i < taille; i++) {
        if (T[i] == x) {
            frequence++;
        }
    }
    return frequence;
}

void Histogramme(int A[], int B[]) {
    for (int i = 0; i < 21; i++) {
        B[i] = Frequence(A, N, i);
    }
}

void Lecture(int tableau[]) {
    printf("Entrez %d notes : \n", N);
    for (int i = 0; i < N; i++) {
        printf("Note %d : ", i+1);
        scanf("%d", &tableau[i]);
    }
    
}

void Ecriture(int tableau[], int taille) {
    printf("Contenu du tableau : \n");
    for (int i = 0; i < taille; i++) {
        printf("%d ", tableau[i]);
    }
    printf("\n");    
}


void main() {
    int Note[N], Histo[21];

    printf("Préparation du tableau des notes\n");
    Lecture(Note);
    Ecriture(Note, N);

    Histogramme(Note, Histo);
    printf("Voici le tableau histogramme qui répertorie les fréquences de chaque note\n");
    Ecriture(Histo, 21);
}