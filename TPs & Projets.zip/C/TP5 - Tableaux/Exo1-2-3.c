#include <stdio.h>

#define N 5

void Lecture(int tableau[]) {
    printf("Entrez %d entiers : \n", N);
    for (int i = 0; i < N; i++) {
        printf("Elément %d : ", i+1);
        scanf("%d", &tableau[i]);
    }
    
}

void Ecriture(int tableau[]) {
    printf("Contenu du tableau : \n");
    for (int i = 0; i < N; i++) {
        printf("%d ", tableau[i]);
    }
    printf("\n");    
}

int Position(int T[], int x) {
    for (int i = 0; i < N; i++) {
        if (T[i] == x) {
            printf("L'élément %d se trouve en position %d\n", x, i);
            return i;
        }
    }
    printf("Elément %d introuvable dans le tableau\n", x);
    return -1;
}

void Somme(int A[], int B[], int Result[]) {
    for (int i = 0; i < N; i++) {
        Result[i] = A[i] + B[i];
    }
}

void main() {
    int tableau[N], A[N], B[N], C[N], x;

    printf("Préparation du tableau A\n");
    Lecture(A);
    Ecriture(A);

    printf("Préparation du tableau B\n");
    Lecture(B);
    Ecriture(B);

    printf("Entrez un entier à chercher dans le tableau A : ");
    scanf("%d", &x);
    Position(tableau, x);

    printf("Somme des deux tableaux \n");
    Somme(A, B, C);
    Ecriture(C);
}