#include <stdio.h>
#include <string.h>

int Occurrence(char string[], char c) {
    int occurrence = 0;
    for (int i = 0; i < strlen(string); i++) {
        if (string[i] == c) {
            occurrence++;
        }
    }
    return occurrence;    
}

void main() {
    char chaine[15] = "ensemble", e = 'e';
    printf("%d\n", Occurrence(chaine, e));
}