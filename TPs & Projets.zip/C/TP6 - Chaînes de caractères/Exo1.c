#include <stdio.h>
#include <string.h>

void Copie(char A[], char B[]) {
    for (int i = 0; i < strlen(A); i++) {
        B[i] = A[i];
    }
    B[strlen(A)] = '\0';
}

void main() {
    char A[2], B[10];
    printf("Entrez un mot de 2 lettres : ");
    scanf("%s", A);
    printf("Le mot entré est '%s'\n", A);

    printf("Entrez un mot de 10 lettres maximum : ");
    scanf("%s", B);
    printf("Le mot entré est '%s'\n", B);

    Copie(A, B);

    printf("La copie du premier mot sur le 2e vaux : '%s'\n", B);
}