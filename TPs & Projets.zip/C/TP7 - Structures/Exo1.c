#include <stdio.h>
#include <stdbool.h>
#include <string.h>

#define MAXNOTES 10

struct Date {
    int jour;
    char mois[10];
    int annee;
};

struct Fiche {
    char nom[20];
    char prenom[20];
    struct Date naissance;
    char formation[2];
    bool redoublant;
    int grp_TD;
    int note[MAXNOTES];
    int nbnotes;
};

void main() {
    struct Fiche etudiant;

    strcpy(etudiant.nom, "Harvey");
    strcpy(etudiant.prenom, "John");
    etudiant.naissance.jour = 9;
    strcpy(etudiant.naissance.mois, "Avril");
    etudiant.naissance.annee = 2005;
    strcpy(etudiant.formation, "bu");
    etudiant.redoublant = false;
    etudiant.grp_TD = 2;
    etudiant.note[0] = 14;
    etudiant.note[1] = 16;
    etudiant.nbnotes = 2;

    printf("Voici la fiche de l'étudiant %s %s : \n", etudiant.prenom, etudiant.nom);
    printf("Date de naissance : le %d %s %d\n", etudiant.naissance.jour, etudiant.naissance.mois, etudiant.naissance.annee);
    printf("Formation : %s\n", etudiant.formation);
    printf("Groupe de TD : %d\n", etudiant.grp_TD);
    printf("Ses notes : ");
    for (int i = 0; i < etudiant.nbnotes; i++) {
        printf("%d ", etudiant.note[i]);
    }
    printf("\nNombre total de notes : %d\n", etudiant.nbnotes);
}