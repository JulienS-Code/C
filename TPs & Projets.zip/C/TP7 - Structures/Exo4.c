#include <stdio.h>
#include <stdbool.h>

#define MAXNOTES 5

struct Date {
    int jour;
    char mois[10];
    int annee;
};

struct Fiche {
    char nom[20];
    char prenom[20];
    struct Date naissance;
    char formation[2];
    bool redoublant;
    int grp_TD;
    int note[MAXNOTES];
    int nbnotes;
};

void LireFiche(struct Fiche *f) {
    bool redouble;
    printf("Entrez un nom : ");
    scanf("%s", &(f->nom));
    printf("Entrez un prénom : ");
    scanf("%s", &(f->prenom));
    printf("Indiquez sa date de naissance (jour mois annee): ");
    scanf("%d %s %d", &(f->naissance.jour), &(f->naissance.mois), &(f->naissance.annee));
    printf("Donnez sa formation (2 lettres) : ");
    scanf("%2s", &(f->formation));
    printf("Est-il redoublant ? o/n : ");
    scanf(" %c", redouble);
    if (redouble == 'o')
    {
        &(f->redoublant) = true;
    }
    
}

void EcrireFiche(struct Fiche f) {
    printf("Voici la fiche de l'étudiant %s %s : \n", f.prenom, f.nom);
    printf("Date de naissance : le %d %s %d\n", f.naissance.jour, f.naissance.mois, f.naissance.annee);
    printf("Formation : %s\n", f.formation);
    printf("Groupe de TD : %d\n", f.grp_TD);
    printf("Ses notes : ");
    for (int i = 0; i < f.nbnotes; i++) {
        printf("%d ", f.note[i]);
    }
    printf("\nNombre total de notes : %d\n", f.nbnotes);
}

