#include <stdio.h>

#define DGMAX 5

struct Polynomes {
    float coef[DGMAX - 1];
    int degre;
};

void LirePolynome(struct Polynomes *poly) {
    printf("Saisie d'un polynôme :\n");
    printf("Degré du polynôme : ");
    scanf("%d", &(poly->degre));

    printf("Saisie des coefficients :\n");
    for (int i = 0; i <= poly->degre; ++i) {
        printf("Coefficient pour x^%d : ", poly->degre - i);
        scanf("%f", &(poly->coef[i]));
    }
}


void main() {
    struct Polynomes poly;

    LirePolynome(&poly);

    printf("Polynôme saisi :\n");
    printf("Degré : %d\n", poly.degre);
    printf("Coefficients : ");
    for (int i = 0; i <= poly.degre; ++i) {
        printf("%.2f ", poly.coef[i]);
    }
    printf("\n");
}
