#include <stdio.h>

struct Rationnel{
    int numerateur;
    int denominateur;
};

int pgcd(int a, int b) {
    if (b == 0) {
        return a;
    }
    return pgcd(b, a % b);
}

void simplifier(struct Rationnel *r) {
    int diviseur = pgcd(r->numerateur, r->denominateur);
    r->numerateur /= diviseur;
    r->denominateur /= diviseur;
}

void LireRationnel(struct Rationnel *r) {
    printf("Saisie d'un nombre rationnel :\n");
    printf("Numérateur : ");
    scanf("%d", &(r->numerateur));
    do {
        printf("Dénominateur (différent de zéro) : ");
        scanf("%d", &(r->denominateur));
    } while (r->denominateur == 0);

    simplifier(r);
}

struct Rationnel SommeRationnel(struct Rationnel r1, struct Rationnel r2) {
    struct Rationnel resultat;
    resultat.numerateur = r1.numerateur * r2.denominateur + r2.numerateur * r1.denominateur;
    resultat.denominateur = r1.denominateur * r2.denominateur;
    simplifier(&resultat);
    return resultat;
}

void main() {
    struct Rationnel r1, r2, somme;
    LireRationnel(&r1);
    LireRationnel(&r2);

    somme = SommeRationnel(r1, r2);
    printf("La somme des deux rationnels est : %d/%d\n", somme.numerateur, somme.denominateur);

}