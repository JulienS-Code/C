#include <stdio.h>

void main() {
    char carNumber = '0';
    int codeNumber = '0';

    printf("Code ASCII des chiffres : \n");
    for (int i = 1; i <= 10; i++) {
        printf("caractère %c code %i \n", carNumber, codeNumber);
        carNumber++;
        codeNumber++;
    }

    printf("Code ASCII des lettres : \n");
    char carLetter = 'A';
    int codeLetter = 'A';

    for (int i = 1; i <= 26; i++) {
        printf("caractère %c code %i \n", carLetter, codeLetter);
        carLetter++;
        codeLetter++;
    }
}