#include <stdio.h>
#include <time.h>
#include <stdlib.h>

void main() {
    srand(time(NULL));
    int r = rand()%1000;
    int entree;
    int nbEssai = 10;

    while (nbEssai > 0) {
        printf("Entrez un entier entre 0 et 1000 : ");
        scanf("%i", &entree);

        if (entree > r)  {
            printf("Trop grand\n");
        } else if (entree < r) {
            printf("Trop petit\n");
        } else {
            printf("Gagné en %i essais\n", 10 - nbEssai);
        }
        nbEssai--;
    }
    printf("Perdu, le nombre secret était %i\n", r);
    
    
}