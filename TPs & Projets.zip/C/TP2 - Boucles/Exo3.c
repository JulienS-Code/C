#include <stdio.h>

void main() {
    char car;
    printf("Entrez un caractère : ");
    scanf(" %c", &car);

    if (car >= 'a' && car <= 'z') {
        printf("Il s'agit d'une minuscule \n");
    } else if (car >= 'A' && car <= 'Z') {
        printf("Il s'agit d'une majuscule \n");
    } else if (car >= '0' && car <= '9') {
        printf("Il s'agit d'un chiffre \n");
    } else {
        printf("Il s'agit d'un carctère non alphanumérique \n");
    }
}