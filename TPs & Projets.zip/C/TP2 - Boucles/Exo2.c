#include <stdio.h>

void main() {
    int a;
    int nbEntier = 0;
    int somme = 0;
    double moyenne;

    do
    {
        printf("Entrez un entier positif ou négatif pour stopper : ");
        scanf("%i", &a);
        if (a >= 0) {
            somme += a;
            nbEntier++; 
        }
    } while (a >= 0);
    
    moyenne = (double)somme / nbEntier;
    printf("Moyenne des entiers positifs : %f \n", moyenne);
}