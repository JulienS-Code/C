#include <stdio.h>

void main() {
    char entree;
    char continu;

    do {
        do {
            printf("********** Menu **********\n");
            printf("A --> Accueil\n");
            printf("H --> Histoire\n");
            printf("T --> Architecture\n");
            printf("I --> Activités\n");
            printf("P --> Infos Pratiques\n");
            printf("**************************\n");
            scanf(" %c", entree);

            switch (entree)
            {
            case 'A':
                printf("Vous êtes à l'accueil\n");
                break;
            case 'H':
                printf("Vous êtes dans la page Histoire\n");
                break;
            case 'T':
                printf("Vous êtes dans la page Architecture\n");
                break;
            case 'I':
                printf("Vous êtes dans la page Activités\n");
                break;
            case 'P':
                printf("Vous êtes dans la page Infos Pratiques\n");
                break;
            default:
                printf("Veuillez entrer une lettre du menu\n\n");
            }
        } while (entree != 'A' && entree != 'H' && entree != 'T' && entree != 'I' && entree != 'P');

        printf("Voullez-vous continuer ? (o/n) : \n");
        scanf(" %c", &continu);

    } while (continu == 'o');

    printf("Vous avez quitté\n");
}