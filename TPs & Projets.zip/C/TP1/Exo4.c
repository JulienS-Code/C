#include <stdio.h>

void main() {
    int a;
    int b;
    printf("Donnez 2 entiers a et b : ");
    scanf("%d %d", &a, &b);
    printf("a = %d \nb = %d \n", a, b);

    int somme = a + b;
    printf("La somme de a et b vaut : %d \n", somme);

    int a2 = 0;
    int b2 = 0;
    int a3 = 0;
    int b3 = 0;

    if (a % 2 == 0 && a % 3 == 0) {
        printf("a est divisible par 2 et 3\n");
    } else if (a % 2 == 0) {
        printf("a est divisible par 2\n");
    } else if (a % 3 == 0) {
        printf("a est divisible par 3\n");
    }
    if (b % 2 == 0 && b % 3 == 0) {
        printf("b est divisible par 2 et 3\n");
    } else if (b % 2 == 0) {
        printf("b est divisible par 2\n");
    } else if (b % 3 == 0) {
        printf("b est divisible par 3\n");
    }
}