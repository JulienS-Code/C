#include <stdio.h>
#include <stdlib.h>

void main() {
    int a;
    int b;
    printf("Donnez 2 entiers a et b : ");
    scanf("%d %d", &a, &b);

    int somme = a + b;
    printf("La somme de a et b vaut : %d \n", somme);

    int diff = abs(a - b);
    printf("La différence de a et b vaut : %d \n", diff);

    int produit = a * b;
    printf("Le produit de a et b vaut : %d \n", produit);

    if (b != 0) {
        double quotient = (double) a / (double) b;
        printf("La différence de a et b vaut : %f \n", quotient);
    } else {
        printf("On ne peut pas diviser par zéro");
    }
}