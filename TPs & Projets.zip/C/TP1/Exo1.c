#include <stdio.h>
#include <time.h>
#include <stdlib.h>

void main() {
    printf("Bonjour le monde !\n");

    int a, b, c;
    printf("Donner 3 valeurs : ");
    scanf("%d %d %d", &a, &b, &c);

    double average = (a+b+c) / 3.0;
    printf("%f \n", average);

    for (int i = 0; i < 20; i++) {
        printf("Bonjour\n");
    }

    int somme = 0;
    int k = a;
    while (k <= b) {
        somme += k;
        k++;
    }
    printf("La somme des entiers entre a et b inclus vaut : %d \n", somme);

    srand(time(NULL));
    int r = rand()%1000;
    printf("Nombre aléatoire entre 0 et 1000 : %d \n", r);
    for (int i = 1; i <= r; i++) {
        if (r % i == 0) {
            printf("%d \n", i);
        }
    }

    printf("Affiche les codes ascii de toutes les lettres de l'alphabet en majuscules : \n");
    char lettre = 'A';
    for (int i = 0; i < 26; i++) {
        printf("%c : %d \n", lettre, lettre);
        lettre++;
    }
}