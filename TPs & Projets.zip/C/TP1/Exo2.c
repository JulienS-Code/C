#include <stdio.h>

void main() {
    printf("Mon nom et prénom:  Synaeve Julien \n");
}

// Le résultat d'une compilation sans paramètres va créer un fichier a.out
// Le fichier exécutable possède le droit 'x' (exécutable) sur chaque profil pour le rendre exécutable peut importe le profil
// Avec la commande -o CV par exemple