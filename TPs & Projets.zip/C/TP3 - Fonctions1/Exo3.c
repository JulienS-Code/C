#include <stdio.h>


int Exp(int n, int m) {
    int expo = 1;
    for (int i = 1; i <= m; i++) {
        expo *= n;
    }
    return expo;
}

void main() {
    int n, m;
    do
    {
        printf("Entrez un entier n et m avec m >= 0 : ");
        scanf("%i %i", &n ,&m);
    } while (m < 0);
    
    int expo = Exp(n, m);
    printf("%i puissance %i vaut %i\n", n, m, expo);
}