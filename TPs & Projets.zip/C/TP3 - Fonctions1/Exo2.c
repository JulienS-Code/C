#include <stdio.h>

void LirePositif() {
    int valeur;
    do
    {
        printf("Entrez un entier : ");
        scanf("%i", &valeur);
        if (valeur > 0)
        {
            printf("Le premier entier positif saisi est : %i\n", valeur);
        }
        
    } while (valeur <= 0);
    
}

void main() {
    LirePositif();
}