#include <stdio.h>
#include <time.h>
#include <stdlib.h>

char car, entree, repeat;

void Average() {
    int valeur;
    double nb_entier = 0, somme = 0;
    do {  
        printf("Entrez une liste d'entiers positifs : ");
        scanf("%i", &valeur);
        if (valeur >= 0) {
            somme += valeur;
            nb_entier++;
        }
    } while (valeur >= 0);
    
    printf("La moyenne de cette liste vaut : %f\n", somme/nb_entier);
}

void Test() {
    printf("Entrez un caractère : ");
    scanf(" %c", &car);

    if (car >= 'a' && car <= 'z') {
        printf("Il s'agit d'une minuscule \n");
    } else if (car >= 'A' && car <= 'Z') {
        printf("Il s'agit d'une majuscule \n");
    } else if (car >= '0' && car <= '9') {
        printf("Il s'agit d'un chiffre \n");
    } else {
        printf("Il s'agit d'un carctère non alphanumérique \n");
    }
}

void Search() {
    srand(time(NULL));
    int r = rand()%1000;
    int entree;
    int nbEssai = 10;

    while (nbEssai > 0 || entree != r) {
        printf("Entrez un entier entre 0 et 1000 : ");
        scanf("%i", &entree);

        if (entree > r)  {
            printf("Trop grand\n");
        } else if (entree < r) {
            printf("Trop petit\n");
        } else {
            printf("Gagné en %i essais\n", 10 - nbEssai);
        }
        nbEssai--;
    }
    printf("Perdu, le nombre secret était %i\n", r);
}

void ASCII() {
    char carNumber = '0';
    int codeNumber = '0';

    printf("Code ASCII des chiffres : \n");
    for (int i = 1; i <= 10; i++) {
        printf("caractère %c code %i \n", carNumber, codeNumber);
        carNumber++;
        codeNumber++;
    }

    printf("Code ASCII des lettres : \n");
    char carLetter = 'A';
    int codeLetter = 'A';

    for (int i = 1; i <= 26; i++) {
        printf("caractère %c code %i \n", carLetter, codeLetter);
        carLetter++;
        codeLetter++;
    }
}


void main() {

    do
    {
        do
        {
            printf("********** Menu **********\n");
            printf("A --> Average of list\n");
            printf("T --> Test on caracters\n");
            printf("S --> Search a number\n");
            printf("C --> Code ASCII\n");
            printf("**************************\n\n");
            scanf(" %c", &entree);

            switch (entree)
            {
            case 'A':
                Average();
                break;
            case 'T':
                Test();
                break;
            case 'S':
                Search();
                break;
            case 'C':
                ASCII();
                break;
            default:
                printf("Veuillez entrer une option du menu\n\n");
                break;
            }

        } while (entree != 'A' && entree != 'T' && entree != 'S' && entree != 'C');

        printf("Voullez-vous continuer ? (O/n) : \n");
        scanf(" %c", &repeat);
        
    } while (repeat == 'o' || repeat == 'O');
    

    

    

}