#include <stdio.h>

int Pgcd(int n, int m) {
    if (n < 0)
        n = -n;

    if (m < 0)
        m = -m;

    while (m != 0)
    {
        int temp = m;
        m = n % m;
        n = temp;
    }

    return n;
}

void main() {
    int n, m;
    printf("Entrez deux entiers n et m : ");
    scanf("%d %d", &n, &m);

    if (n == 0) {
        printf("n doit être différent de zéro.\n");
    }

    int pgcd = Pgcd(n, m);
    printf("Le PGCD de %d et %d est : %d\n", n, m, pgcd);
}