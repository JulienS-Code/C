#include <stdio.h>

int Ppcm(int n, int m) {
    int max;
    if (n > m) {
        max = n;
    }
    else {
        max = m;
    }
    while (1) {
        if (max % n == 0 && max % m == 0) {
            return max;
        }
        max++;
    }
}

void main() {
    int n, m;
    printf("Entrez deux entiers non nuls (n et m) : ");
    scanf("%d %d", &n, &m);

    if (n == 0 || m == 0) {
        printf("Les entiers doivent Ãªtre non nuls.\n");
    }

    int ppcm = Ppcm(n, m);
    printf("Le PPCM de %d et %d est : %d\n", n, m, ppcm);
}